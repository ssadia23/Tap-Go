//
//  Tap_GoTests.swift
//  Tap&GoTests
//
//  Created by Sadia Sultana on 2/1/25.
//

import Testing
@testable import Tap_Go

struct Tap_GoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
