//
//  Tap_GoApp.swift
//  Tap&Go
//
//  Created by Sadia Sultana on 2/1/25.
//

import SwiftUI

@main
struct Tap_GoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
